pageOne = $("#postPage1");
pageTwo = $("#postPage2");
pageThree = $("#postPage3");
let a = pageOne.hasClass("postCont");
console.log(a);
